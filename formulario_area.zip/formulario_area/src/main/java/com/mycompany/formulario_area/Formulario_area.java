/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.formulario_area;

import Formularios.FormularioArea;
import com.sun.jdi.request.EventRequestManager;

/**
 *
 * @author PELAEZ
 */
public class Formulario_area {

    public static void main(String[] args) {
        FormularioArea ventana = new FormularioArea();
       ventana.setVisible(true);
       ventana.setLocationRelativeTo(null);
    }
}
